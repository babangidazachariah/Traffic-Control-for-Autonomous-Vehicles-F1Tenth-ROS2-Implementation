
        self.peeredVeh = None
        self.peeredVehInitTime = 0.0
        
        self.lastDSRCMsgTime = 0.
        self.timer = self.create_timer(0.1, self.CheckLastDSRCDuration) 
        
        
    def CheckLastDSRCDuration(self):
        """
            changes speed to 1.0 if the last time dsrcmsg was received from a peered vehicle 
            is greater than 3 and this vehicle has stoped at a stop line.
        """
        now = time.time()
        if (self.lastDSRCMsgTime - now) > 3:
            self.speed = 1.0
    
    def P2PTrafficSchedule(self, dsrcmsg):
        """
            
        """
        if dsrcmsg.initialtime is not None  and dsrcmsg.speed is not None and self.initialTime is not None:
            if dsrcmsg.vehicleid != self.vehicleID: #Check to ensure the received DRSC message is not from the vehicle
                #print(dsrcmsg.vehicleid)
                
                if dsrcmsg.approachleg[-2:] == self.approachLeg[-2:] : #Both vehicles are approaching or around the same intersection
                    if dsrcmsg.initialtime > self.initialTime and dsrcmsg.initialtime > self.peeredVehInitTime and self.peeredVeh != dsrcmsg.vehicleid:
                        #this vehicle becomes the new vehicle to wait upon.
                        self.peeredVeh = dsrcmsg.vehicleid
                        self.peeredVehInitTime = dsrcmsg.initialtime
                    
               