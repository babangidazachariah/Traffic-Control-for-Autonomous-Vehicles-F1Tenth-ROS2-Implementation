###https://github.com/f1tenth/ESweek2021_educationclassA3/blob/main/01_Follow_The_Gap/drivers.py
import numpy as np

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan

from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive

class DisparityExtender(Node):


    CARWIDTH = 0.31 ##Original value = 0.31
    
    # the min difference between adjacent LiDAR points for us to call them disparate
    DIFFERENCETHRESHOLD = 1.
    
    # the extra safety room we plan for along walls (as a percentage of car_width/2)
    SAFETYPERCENTAGE = 300. ##Original value
    
    STRAIGHTSSTEERINGANGLE = np.pi / 18  # 10 degrees

    def __init__(self):
        """" Initialize the topics, publishers and subscribers
        """
        super().__init__("DisparityExtenderNode")
                        
        # used when calculating the angles of the LiDAR data
        self.radians_per_elem = None
        self.speed = 1

    def GetStraightSteeringAngle(self):
        return self.STRAIGHTSSTEERINGANGLE
        
    def SetSpeed(self, speed):
        """
            The function, SetSpeed is used to set the speed of the vehicle either
        """
        self.speed = speed
    def preprocess_lidar(self, ranges):
        """ Any preprocessing of the LiDAR data can be done in this function.
            Possible Improvements: smoothing of outliers in the data and placing
            a cap on the maximum distance a point can be.
        """
        # remove quadrant of LiDAR directly behind us
        eighth = int(len(ranges)/8)
        return np.array(ranges[eighth:-eighth])
    
     
    def get_differences(self, ranges):
        """ Gets the absolute difference between adjacent elements in
            in the LiDAR data and returns them in an array.
            Possible Improvements: replace for loop with numpy array arithmetic
        """
        differences = [0.] # set first element to 0
        for i in range(1, len(ranges)):
            differences.append(abs(ranges[i]-ranges[i-1]))
        return differences
    
    def get_disparities(self, differences, threshold):
        """ Gets the indexes of the LiDAR points that were greatly
            different to their adjacent point.
            Possible Improvements: replace for loop with numpy array arithmetic
        """
        disparities = []
        for index, difference in enumerate(differences):
            if difference > threshold:
                disparities.append(index)
        return disparities

    def get_num_points_to_cover(self, dist, width):
        """ Returns the number of LiDAR points that correspond to a width at
            a given distance.
            We calculate the angle that would span the width at this distance,
            then convert this angle to the number of LiDAR points that
            span this angle.
            Current math for angle:
                sin(angle/2) = (w/2)/d) = w/2d
                angle/2 = sininv(w/2d)
                angle = 2sininv(w/2d)
                where w is the width to cover, and d is the distance to the close
                point.
            Possible Improvements: use a different method to calculate the angle
        """
        angle = 2*np.arcsin(width/(2*dist))
        num_points = int(np.ceil(angle / self.radians_per_point))
        return num_points

    def cover_points(self, num_points, start_idx, cover_right, ranges):
        """ 'covers' a number of LiDAR points with the distance of a closer
            LiDAR point, to avoid us crashing with the corner of the car.
            num_points: the number of points to cover
            start_idx: the LiDAR point we are using as our distance
            cover_right: True/False, decides whether we cover the points to
                         right or to the left of start_idx
            ranges: the LiDAR points

            Possible improvements: reduce this function to fewer lines
        """
        new_dist = ranges[start_idx]
        if cover_right:
            for i in range(num_points):
                next_idx = start_idx+1+i
                if next_idx >= len(ranges): break
                if ranges[next_idx] > new_dist:
                    ranges[next_idx] = new_dist
        else:
            for i in range(num_points):
                next_idx = start_idx-1-i
                if next_idx < 0: break
                if ranges[next_idx] > new_dist:
                    ranges[next_idx] = new_dist
        return ranges

    def extend_disparities(self, disparities, ranges, car_width, extra_pct):
        """ For each pair of points we have decided have a large difference
            between them, we choose which side to cover (the opposite to
            the closer point), call the cover function, and return the
            resultant covered array.
            Possible Improvements: reduce to fewer lines
        """
        width_to_cover = (car_width/2) * (1+extra_pct/100)
        for index in disparities:
            first_idx = index-1
            points = ranges[first_idx:first_idx+2]
            close_idx = first_idx+np.argmin(points)
            far_idx = first_idx+np.argmax(points)
            close_dist = ranges[close_idx]
            num_points_to_cover = self.get_num_points_to_cover(close_dist,
                    width_to_cover)
            cover_right = close_idx < far_idx
            ranges = self.cover_points(num_points_to_cover, close_idx,
                cover_right, ranges)
        return ranges
            
    def get_steering_angle(self, range_index, range_len):
        """ Calculate the angle that corresponds to a given LiDAR point and
            process it into a steering angle.
            Possible improvements: smoothing of aggressive steering angles
        """
        lidar_angle = (range_index - (range_len/2)) * self.radians_per_point
        steering_angle = np.clip(lidar_angle, np.radians(-90), np.radians(90))
        return steering_angle

    def GetDisparityExtenderSteerAngle(self, ranges, radPerPoint):
        """
            This function is entry point for other Nodes trying to use this DisparityExtender class.
            Thus, it expected that Lidar Scans would have been preprocessed before calling
            The function returns the steering angle.
        """
        self.radians_per_point = radPerPoint
        differences = self.get_differences(ranges)
        disparities = self.get_disparities(differences, self.DIFFERENCETHRESHOLD)
        proc_ranges = self.extend_disparities(disparities, ranges,
                self.CARWIDTH, self.SAFETYPERCENTAGE)
        steering_angle = self.get_steering_angle(proc_ranges.argmax(),
                len(proc_ranges))
        return steering_angle
    
    def process_lidar(self, data):
        """ Run the disparity extender algorithm!
            Possible improvements: varying the speed based on the
            steering angle or the distance to the farthest point.
        """
        self.radians_per_point = (2*np.pi)/len(data.ranges)
        proc_ranges = self.preprocess_lidar(data.ranges)
        differences = self.get_differences(proc_ranges)
        disparities = self.get_disparities(differences, self.DIFFERENCETHRESHOLD)
        proc_ranges = self.extend_disparities(disparities, proc_ranges,
                self.CARWIDTH, self.SAFETYPERCENTAGE)
        steering_angle = self.get_steering_angle(proc_ranges.argmax(),
                len(proc_ranges))
        #speed = self.SPEED
        
        
        # Get the final steering angle and speed value
        
        if abs(steering_angle) > self.STRAIGHTSSTEERINGANGLE:
            speed = 1.
        else:
            speed = self.speed
            
            
        ##return speed, steering_angle
         # Send back the speed and steering angle to the simulation
        #return speed, steering_angle
        #Prepare parameters for driving the vehicle
        driveMsg = AckermannDriveStamped()
        driveMsg.header = data.header
        driveMsg.drive.steering_angle = steering_angle
        driveMsg.drive.speed = speed
        self.drivePubs.publish(driveMsg)


def main(args=None):
    rclpy.init(args=args)
    print("Disparity Extender Gap Following Algorithm")
    gapFollowNode = DisparityExtender()
    rclpy.spin(gapFollowNode)
    
    gapFollowNode.destroy_node()
    rclpy.shutdown()
    
if __name__ == "main":
    main()

